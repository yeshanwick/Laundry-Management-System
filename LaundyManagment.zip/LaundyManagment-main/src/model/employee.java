/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Damidu
 */
public class employee {
    
    private String empID;
    private String empName;
    private String empTeleNumber;
    private String nicNo;
    private String jobTitle;
    private String email;
    private String address;
    private int workingHours;
    private int otHours;
    private double otRate;
    private double salary;

    /**
     * @return the empID
     */
    public String getEmpID() {
        return empID;
    }

    /**
     * @param empID the empID to set
     */
    public void setEmpID(String empID) {
        this.empID = empID;
    }

    /**
     * @return the empName
     */
    public String getEmpName() {
        return empName;
    }

    /**
     * @param empName the empName to set
     */
    public void setEmpName(String empName) {
        this.empName = empName;
    }

    /**
     * @return the empTeleNumber
     */
    public String getEmpTeleNumber() {
        return empTeleNumber;
    }

    /**
     * @param empTeleNumber the empTeleNumber to set
     */
    public void setEmpTeleNumber(String empTeleNumber) {
        this.empTeleNumber = empTeleNumber;
    }

    /**
     * @return the nicNo
     */
    public String getNicNo() {
        return nicNo;
    }

    /**
     * @param nicNo the nicNo to set
     */
    public void setNicNo(String nicNo) {
        this.nicNo = nicNo;
    }

    /**
     * @return the jobTitle
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * @param jobTitle the jobTitle to set
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the workingHours
     */
    public int getWorkingHours() {
        return workingHours;
    }

    /**
     * @param workingHours the workingHours to set
     */
    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }

    /**
     * @return the otHours
     */
    public int getOtHours() {
        return otHours;
    }

    /**
     * @param otHours the otHours to set
     */
    public void setOtHours(int otHours) {
        this.otHours = otHours;
    }

    /**
     * @return the otRate
     */
    public double getOtRate() {
        return otRate;
    }

    /**
     * @param otRate the otRate to set
     */
    public void setOtRate(double otRate) {
        this.otRate = otRate;
    }

    /**
     * @return the salary
     */
    public double getSalary() {
        return salary;
    }

    /**
     * @param salary the salary to set
     */
    public void setSalary(double salary) {
        this.salary = salary;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    
    
    
}
